<script setup>
import { ref, onMounted } from 'vue';
import store from '@/store';
import AceEditor from '@/components/Blockly/AceEditor/index.vue';

</script>

<template>
  <div class="teach-container">
    <AceEditor v-model="store.pyCode" />
  </div>
</template>

<style src="./index.css" scoped></style>
